import React from 'react';
import { SnakeGame } from './components/SnakeGame';
import { Github, Info } from 'lucide-react';

const App: React.FC = () => {
  return (
    <div className="h-[100dvh] w-full flex flex-col items-center justify-center bg-zinc-950 text-zinc-200">
      <header className="absolute top-0 w-full p-6 flex justify-between items-center z-10">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse" />
          <h1 className="text-xl font-bold tracking-tight text-zinc-100">Zen Snake</h1>
        </div>
        <div className="flex gap-4 opacity-50 hover:opacity-100 transition-opacity">
           {/* Placeholder for future links */}
           <Info size={20} className="cursor-pointer" />
        </div>
      </header>

      <main className="flex-1 w-full flex flex-col items-center justify-center p-4">
        <SnakeGame />
      </main>

      <footer className="absolute bottom-4 text-xs text-zinc-600 font-medium tracking-wide">
        USE ARROW KEYS OR ON-SCREEN CONTROLS
      </footer>
    </div>
  );
};

export default App;