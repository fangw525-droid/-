import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Play, RotateCcw, Pause, Trophy } from 'lucide-react';
import { Point, GameStatus, Direction, DIRECTIONS } from '../types';
import { GRID_SIZE, INITIAL_SPEED, SPEED_INCREMENT, MIN_SPEED, INITIAL_SNAKE } from '../constants';

// Utility for collision detection
const checkCollision = (head: Point, snake: Point[]) => {
  // Wall collision
  if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) return true;
  // Self collision (ignore tail as it will move unless we just ate)
  for (const segment of snake) {
    if (head.x === segment.x && head.y === segment.y) return true;
  }
  return false;
};

// Utility to generate random food position not on snake
const generateFood = (snake: Point[]): Point => {
  let newFood: Point;
  let isOnSnake = true;
  while (isOnSnake) {
    newFood = {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE),
    };
    // eslint-disable-next-line no-loop-func
    isOnSnake = snake.some((segment) => segment.x === newFood.x && segment.y === newFood.y);
  }
  return newFood!;
};

export const SnakeGame: React.FC = () => {
  const [snake, setSnake] = useState<Point[]>(INITIAL_SNAKE);
  const [food, setFood] = useState<Point>({ x: 5, y: 5 });
  const [direction, setDirection] = useState<Direction>('UP');
  const [status, setStatus] = useState<GameStatus>(GameStatus.IDLE);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  
  // Refs for mutable state in the interval to avoid closure staleness without excessive dependencies
  const directionRef = useRef<Direction>('UP');
  const nextDirectionRef = useRef<Direction>('UP'); // Buffer for next move to prevent rapid double-turn suicide
  const speedRef = useRef(INITIAL_SPEED);
  const gameLoopRef = useRef<number | null>(null);

  // Initialize/Reset Game
  const resetGame = useCallback(() => {
    setSnake(INITIAL_SNAKE);
    setDirection('UP');
    directionRef.current = 'UP';
    nextDirectionRef.current = 'UP';
    setScore(0);
    speedRef.current = INITIAL_SPEED;
    setStatus(GameStatus.PLAYING);
    setFood(generateFood(INITIAL_SNAKE));
  }, []);

  const gameOver = useCallback(() => {
    setStatus(GameStatus.GAME_OVER);
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem('zen-snake-highscore', score.toString());
    }
  }, [score, highScore]);

  // Load High Score
  useEffect(() => {
    const saved = localStorage.getItem('zen-snake-highscore');
    if (saved) setHighScore(parseInt(saved, 10));
  }, []);

  // Handle Input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (status !== GameStatus.PLAYING) {
        if (e.code === 'Space' || e.code === 'Enter') {
          if (status === GameStatus.GAME_OVER || status === GameStatus.IDLE) resetGame();
          else if (status === GameStatus.PAUSED) setStatus(GameStatus.PLAYING);
        }
        return;
      }

      const keyMap: Record<string, Direction> = {
        ArrowUp: 'UP',
        ArrowDown: 'DOWN',
        ArrowLeft: 'LEFT',
        ArrowRight: 'RIGHT',
        KeyW: 'UP',
        KeyS: 'DOWN',
        KeyA: 'LEFT',
        KeyD: 'RIGHT',
      };

      const newDir = keyMap[e.code];
      if (newDir) {
        const currentDir = directionRef.current;
        // Prevent 180 degree turns
        const isOpposite =
          (newDir === 'UP' && currentDir === 'DOWN') ||
          (newDir === 'DOWN' && currentDir === 'UP') ||
          (newDir === 'LEFT' && currentDir === 'RIGHT') ||
          (newDir === 'RIGHT' && currentDir === 'LEFT');
        
        if (!isOpposite) {
          nextDirectionRef.current = newDir;
        }
      }
      
      if (e.code === 'Escape' || e.code === 'Space') {
         setStatus(GameStatus.PAUSED);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [status, resetGame]);

  // Game Loop
  useEffect(() => {
    if (status !== GameStatus.PLAYING) {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
      return;
    }

    const moveSnake = () => {
      setSnake((prevSnake) => {
        // Update direction from buffer
        directionRef.current = nextDirectionRef.current;
        setDirection(directionRef.current); // Sync state for UI arrows if needed
        
        const head = prevSnake[0];
        const dirPoint = DIRECTIONS[directionRef.current];
        const newHead = { x: head.x + dirPoint.x, y: head.y + dirPoint.y };

        // 1. Check Collision
        if (checkCollision(newHead, prevSnake)) {
          gameOver();
          return prevSnake;
        }

        const newSnake = [newHead, ...prevSnake];

        // 2. Check Food
        if (newHead.x === food.x && newHead.y === food.y) {
          setScore((s) => s + 1);
          setFood(generateFood(newSnake));
          // Increase speed
          speedRef.current = Math.max(MIN_SPEED, speedRef.current - SPEED_INCREMENT);
          // Restart interval with new speed
          clearInterval(gameLoopRef.current!);
          gameLoopRef.current = window.setInterval(moveSnake, speedRef.current);
        } else {
          newSnake.pop(); // Remove tail
        }

        return newSnake;
      });
    };

    gameLoopRef.current = window.setInterval(moveSnake, speedRef.current);

    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
    };
  }, [status, food, gameOver]); // Dependencies that might trigger a loop reset logic


  // Mobile Control Handler
  const handleDirectionClick = (dir: Direction) => {
    if (status !== GameStatus.PLAYING) return;
    const currentDir = directionRef.current;
    const isOpposite =
      (dir === 'UP' && currentDir === 'DOWN') ||
      (dir === 'DOWN' && currentDir === 'UP') ||
      (dir === 'LEFT' && currentDir === 'RIGHT') ||
      (dir === 'RIGHT' && currentDir === 'LEFT');

    if (!isOpposite) {
      nextDirectionRef.current = dir;
    }
  };

  // --- RENDERING HELPERS ---

  const getCellClass = (x: number, y: number) => {
    if (food.x === x && food.y === y) return 'bg-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.6)] rounded-full animate-bounce scale-90';
    
    const index = snake.findIndex((s) => s.x === x && s.y === y);
    if (index === 0) return 'bg-emerald-400 z-10 rounded-sm shadow-[0_0_10px_rgba(52,211,153,0.5)]'; // Head
    if (index !== -1) return 'bg-emerald-600/90 rounded-sm'; // Body
    
    return 'bg-zinc-800/30 border-zinc-800/50'; // Empty
  };

  // We render a grid of standard DIVs. 
  // For 20x20 = 400 divs, this is performant enough in React 18.
  // A canvas approach would be lighter but this allows Tailwind ease.
  
  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-lg">
      
      {/* Score Board */}
      <div className="flex w-full justify-between items-end px-4">
        <div className="flex flex-col">
           <span className="text-zinc-500 text-xs font-bold tracking-wider uppercase">Score</span>
           <span className="text-4xl font-mono text-zinc-100">{score.toString().padStart(3, '0')}</span>
        </div>
        <div className="flex flex-col items-end">
           <span className="text-zinc-500 text-xs font-bold tracking-wider uppercase flex items-center gap-1">
             <Trophy size={12} /> Best
           </span>
           <span className="text-xl font-mono text-emerald-500">{highScore.toString().padStart(3, '0')}</span>
        </div>
      </div>

      {/* Game Board Container */}
      <div className="relative p-1 bg-zinc-900 rounded-xl border border-zinc-800 shadow-2xl shadow-black/50">
        <div 
          className="grid gap-px bg-zinc-900/50"
          style={{
            gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
            width: 'min(85vw, 400px)',
            aspectRatio: '1/1',
          }}
        >
          {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => {
            const x = i % GRID_SIZE;
            const y = Math.floor(i / GRID_SIZE);
            const isSnake = snake.some(s => s.x === x && s.y === y);
            const isFood = food.x === x && food.y === y;
            
            return (
              <div
                key={i}
                className={`w-full h-full transition-all duration-100 ${isSnake || isFood ? '' : 'border border-zinc-800/20'} ${getCellClass(x, y)}`}
                style={{ borderRadius: isSnake ? '2px' : '0' }}
              />
            );
          })}
        </div>

        {/* Overlays */}
        {status === GameStatus.IDLE && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center rounded-xl z-20">
             <button 
                onClick={resetGame}
                className="group relative px-8 py-3 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold rounded-full transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
             >
                <Play size={20} fill="currentColor" />
                START GAME
             </button>
          </div>
        )}

        {status === GameStatus.GAME_OVER && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center rounded-xl z-20 animate-in fade-in duration-300">
             <h2 className="text-3xl font-black text-rose-500 mb-2 tracking-tighter">GAME OVER</h2>
             <p className="text-zinc-400 mb-6">Score: {score}</p>
             <button 
                onClick={resetGame}
                className="px-6 py-2 bg-zinc-100 hover:bg-white text-zinc-900 font-bold rounded-full transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
             >
                <RotateCcw size={18} />
                TRY AGAIN
             </button>
          </div>
        )}

        {status === GameStatus.PAUSED && (
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center rounded-xl z-20">
             <button 
                onClick={() => setStatus(GameStatus.PLAYING)}
                className="w-16 h-16 bg-zinc-800 hover:bg-zinc-700 text-emerald-500 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-90"
             >
                <Play size={32} fill="currentColor" className="ml-1" />
             </button>
          </div>
        )}
      </div>

      {/* Controls (Mobile Friendly) */}
      <div className="w-full max-w-[200px] aspect-square grid grid-cols-3 grid-rows-2 gap-2 md:hidden">
          <div className="col-start-2">
            <button 
              className="w-full h-full bg-zinc-800/50 hover:bg-zinc-700 rounded-xl active:bg-emerald-500/20 flex items-center justify-center transition-colors"
              onPointerDown={(e) => { e.preventDefault(); handleDirectionClick('UP'); }}
            >
              <div className="w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-b-[12px] border-b-zinc-400" />
            </button>
          </div>
          <div className="col-start-1 row-start-2">
            <button 
              className="w-full h-full bg-zinc-800/50 hover:bg-zinc-700 rounded-xl active:bg-emerald-500/20 flex items-center justify-center transition-colors"
              onPointerDown={(e) => { e.preventDefault(); handleDirectionClick('LEFT'); }}
            >
               <div className="w-0 h-0 border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent border-r-[12px] border-r-zinc-400" />
            </button>
          </div>
          <div className="col-start-2 row-start-2">
            <button 
               className="w-full h-full bg-zinc-800/50 hover:bg-zinc-700 rounded-xl active:bg-emerald-500/20 flex items-center justify-center transition-colors"
               onPointerDown={(e) => { e.preventDefault(); handleDirectionClick('DOWN'); }}
            >
              <div className="w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[12px] border-t-zinc-400" />
            </button>
          </div>
          <div className="col-start-3 row-start-2">
            <button 
               className="w-full h-full bg-zinc-800/50 hover:bg-zinc-700 rounded-xl active:bg-emerald-500/20 flex items-center justify-center transition-colors"
               onPointerDown={(e) => { e.preventDefault(); handleDirectionClick('RIGHT'); }}
            >
               <div className="w-0 h-0 border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent border-l-[12px] border-l-zinc-400" />
            </button>
          </div>
      </div>

      <div className="hidden md:flex gap-4 text-zinc-500 text-sm">
        <span className="flex items-center gap-1"><kbd className="bg-zinc-800 px-2 py-1 rounded text-zinc-300 font-mono text-xs border border-zinc-700">SPACE</kbd> Pause</span>
        <span className="flex items-center gap-1"><kbd className="bg-zinc-800 px-2 py-1 rounded text-zinc-300 font-mono text-xs border border-zinc-700">ARROWS</kbd> Move</span>
      </div>

    </div>
  );
};